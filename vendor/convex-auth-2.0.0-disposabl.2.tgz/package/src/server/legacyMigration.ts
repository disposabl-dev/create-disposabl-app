import { internalMutationGeneric } from "convex/server";
import { v } from "convex/values";
import type { ComponentApi as Core } from "../component/_generated/component.ts";
import type { ComponentApi as Google } from "../components/google/_generated/component.ts";

/**
 * Export the returned function as an app-internal mutation. Run repeatedly until
 * `complete` is true. All component calls share one transaction: a conflict or
 * failed target import rolls back the core cursor, including its final gate.
 * Never call `_internal_dangerous_advance` independently.
 */
export function setupLegacyGoogleMigration(core: Core, google: Google) {
  return internalMutationGeneric({
    args: {},
    returns: v.object({
      phase: v.string(),
      count: v.number(),
      complete: v.boolean(),
    }),
    handler: async (ctx) => {
      await ctx.runMutation(google.migration._internal_dangerous_lock, {});
      const batch = await ctx.runMutation(
        core.migration._internal_dangerous_advance,
        {},
      );
      if (batch.phase === "cutoffs") {
        const rows = batch.rows.map((row) => {
          if (!("digest" in row)) throw new Error("Invalid cutoff batch");
          return row;
        });
        await ctx.runMutation(google.migration.importCutoffs, { rows });
      } else if (batch.phase === "users") {
        const rows = batch.rows.map((row) => {
          if (!("requestedAt" in row))
            throw new Error("Invalid user fence batch");
          return row;
        });
        await ctx.runMutation(google.migration.importErasedUsers, { rows });
      } else if (batch.phase === "accounts") {
        const rows = batch.rows.map((row) => {
          if (!("providerAccountId" in row) || row.provider !== "google")
            throw new Error("Invalid Google account batch");
          return {
            providerAccountId: row.providerAccountId,
            userId: row.userId,
          };
        });
        await ctx.runMutation(google.migration.importAccounts, { rows });
      } else if (batch.rows.length)
        throw new Error("Unexpected migration rows");
      if (batch.phase === "complete")
        await ctx.runMutation(google.migration._internal_dangerous_unlock, {});
      return {
        phase: batch.phase,
        count: batch.rows.length,
        complete: batch.phase === "complete",
      };
    },
  });
}
