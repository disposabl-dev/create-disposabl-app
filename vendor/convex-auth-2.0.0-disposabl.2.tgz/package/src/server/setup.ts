import {
  createFunctionHandle,
  GenericDataModel,
  GenericMutationCtx,
  mutationGeneric,
  queryGeneric,
  RegisteredMutation,
  RegisteredQuery,
  ReturnValueForOptionalValidator,
} from "convex/server";
import { ObjectType, PropertyValidators, v, Validator } from "convex/values";
import type { ComponentApi } from "../component/_generated/component.ts";
import {
  type TokenBundle,
  vRefreshResult,
  type RefreshResult,
  type ConvexAuthCtx,
  type UserCallbacks,
} from "../lib/types.ts";
import { getAuthUserId } from "./userId.ts";
import { resolveTtlConfig } from "../lib/ttl.ts";
import { componentPathOf } from "../lib/componentPath.ts";

/**
 * A type for a factory that returns a `RegisteredMutation` with a handler that
 * has access to method-bound auth helpers on `ctx.convexAuth`.
 *
 * The signature mirrors convex's own `MutationBuilder` inference, simplified
 * where methods never need the generality: `args` is required (dropping the
 * zero-arg/function shorthand machinery) and there is no app data model
 * (methods are app-agnostic; their storage lives behind their own
 * component's functions). `returns` keeps convex's exact optional-validator
 * scheme: with a validator, the handler's return is constrained to (a promise
 * of) its type; without one, it falls back to whatever the handler declares.
 *
 * @internal Not public until the API for custom methods is stable.
 */
export type AuthMutationBuilder<Profile> = <
  ArgsValidator extends PropertyValidators,
  ReturnsValidator extends
    PropertyValidators | Validator<unknown, "required", string> | void,
  ReturnValue extends ReturnValueForOptionalValidator<ReturnsValidator> =
    ReturnValueForOptionalValidator<ReturnsValidator>,
>(fn: {
  args: ArgsValidator;
  returns?: ReturnsValidator;
  handler: (
    ctx: GenericMutationCtx<GenericDataModel> & ConvexAuthCtx<Profile>,
    args: ObjectType<ArgsValidator>,
  ) => ReturnValue;
}) => RegisteredMutation<"public", ObjectType<ArgsValidator>, ReturnValue>;

/**
 * The function builders a method gets from {@link AuthCore.bindMethod}.
 *
 * Each builds a public Convex function whose handler receives the
 * method-bound helpers on `ctx.convexAuth` alongside the standard ctx.
 *
 * @internal Not public until the API for custom methods is stable.
 */
export type MethodBuilders<Profile> = {
  authMutation: AuthMutationBuilder<Profile>;
};

/**
 * The core auth API returned by {@link setupConvexAuth}: the session handlers the
 * app re-exports. The sign-in methods also use it to bind to the core.
 */
export type AuthCore<UsersTable extends string = string> = {
  /**
   * The name of the app's users table, as configured on {@link setupConvexAuth}.
   *
   * Carried on the value (not just in the type) so method setup functions
   * can infer `UsersTable` from the `core` they are handed, and so the name is
   * available for error messages.
   */
  usersTable: UsersTable;
  /**
   * The core component, as passed to {@link setupConvexAuth}.
   *
   * The sign-in methods pass it to `getAuthUserId`. The app must mount the
   * core as `auth`.
   *
   * @internal
   */
  component: ComponentApi;
  /**
   * Signs out of the current session.
   *
   * After this the refresh token is no longer valid.
   */
  signOut: RegisteredMutation<
    "public",
    { refreshToken: string },
    Promise<null>
  >;
  /**
   * Refreshes a session using the given token, rotating the refresh token.
   *
   * Resolves to one of the {@link RefreshResult} outcomes. `rotated` carries a
   * new token bundle to persist; the presented token keeps working until the
   * new refresh token is first used, so a lost response can be retried. A
   * `noSession` result should be treated as signed-out.
   */
  refreshSession: RegisteredMutation<
    "public",
    { refreshToken: string },
    Promise<RefreshResult>
  >;
  /**
   * Reports whether the caller's access token identifies a live session.
   *
   * Convex verifies the token's signature (against the deployment's JWKS)
   * before this query runs, so the result is a trustworthy authentication
   * verdict. SSR hosts call it with the token from the auth cookie to decide
   * authentication state, rather than trusting the (client-controlled) cookie
   * by merely decoding it.
   *
   * The query reads the session, so it returns `false` once the session is
   * gone (signed out elsewhere, revoked, or expired) even while the token
   * itself is still valid, and a subscription re-runs when that happens.
   */
  isAuthenticated: RegisteredQuery<
    "public",
    Record<string, never>,
    Promise<boolean>
  >;
  /**
   * Register a sign-in method with the core and get the function builders its
   * implementation uses.
   *
   * `name` is the name of the sign-in method. The app's user callbacks get it
   * as `method.name`. Two sign-in methods with one name would be
   * indistinguishable, so a duplicate name on this core throws.
   *
   * `createUser` is the app's user-creating callback for this method and
   * `onSignIn` is its optional per-sign-in hook (see {@link UserCallbacks}).
   *
   * Method setup functions call this from inside their `attachUserCallbacks`,
   * once the app has supplied the callbacks, so the builders can close over
   * them and a method with no way to create users cannot exist. It is not
   * meant to be called by application code directly.
   *
   * @internal Not public until the API for custom methods is stable.
   */
  bindMethod<MethodName extends string, Profile>(
    options: {
      name: MethodName;
    } & UserCallbacks<MethodName, Profile, UsersTable>,
  ): MethodBuilders<Profile>;
};

/**
 * Build the app-facing auth-core handlers from the mounted `core` component
 * reference. Returns ready-to-export `signOut`/`refreshSession`/
 * `isAuthenticated` handlers. Give the result to the setup function of each
 * method:
 *
 * ```ts
 * const auth = setupConvexAuth({ component: components.auth });
 * export const { signOut, refreshSession, isAuthenticated } = auth;
 *
 * export const { signUpWithUsernamePassword, signInWithUsernamePassword } =
 *   setupUsernamePassword(auth, {
 *     component: components.authPassword,
 *     usernameComponent: components.authUsername,
 *   }).attachUserCallbacks({ createUser: internal.users.createUserPassword });
 * ```
 *
 * The core never triggers a sign-in itself: it has no idea how any given
 * method authenticates a user. *Triggering sign-in is the responsibility of
 * each method.* A method:
 * 1. verifies the user its own way (checking a password, say),
 * 2. looks the identity's app user up in its own component,
 * 3. calls `completeSignUp` for a new identity, or `completeSignIn` for a
 *    known one, to get a session.
 *
 * The core injects both helpers on `ctx.convexAuth`.
 *
 * Token and session lifetimes are configurable here. The access-token TTL
 * defaults to 1m, and `sessionMaxLifetimeSeconds` to 30d.
 * `refreshInactivityTimeoutSeconds` defaults to the max lifetime and cannot
 * exceed it. The access-token TTL must be shorter than the inactivity timeout,
 * and (since the client refreshes shortly before expiry) comfortably longer
 * than a few seconds.
 *
 * Changes to access token TTLs impact newly minted tokens, not ones that have
 * already been issued. Session/refresh related TTLs apply to all issued tokens.
 */
export function setupConvexAuth<UsersTable extends string = "users">(options: {
  component: ComponentApi;
  /**
   * The name of the app's users table. Defaults to `"users"`.
   *
   * The core never reads or writes the table — it only stores the id the app's
   * `createUser` callback returns. The name is a *type-level* contract: it makes
   * the `attachUserCallbacks` of every method demand a `createUser` returning
   * `Id<usersTable>` and an `onSignIn` taking one, so an app cannot accidentally
   * hand back an id from some other table (and, because the app then declares
   * `v.id(usersTable)`, Convex enforces the same thing at runtime).
   *
   * Set this if the app's users live in a table with a different name:
   *
   * ```ts
   * const auth = setupConvexAuth({ component: components.auth, usersTable: "members" });
   * ```
   */
  usersTable?: UsersTable;
  /**
   * Access-token lifetime in seconds. Defaults to 60 (1 minute).
   *
   * Changes to this value impact newly minted tokens, not ones that have
   * already been issued.
   */
  accessTokenTtlSeconds?: number;
  /**
   * How long in seconds a session may go without refreshing before it
   * expires.
   *
   * Cannot exceed `sessionMaxLifetimeSeconds`.
   *
   * A connected client refreshes about once per access-token TTL, so this is
   * how long a client may stay away (closed, offline, asleep) and still
   * resume its session.
   *
   * Changes to this value apply to every session, including ones that already
   * exist: a session expires this long after its last refresh, under the
   * value configured when it is checked. Lowering it thus ends sessions that
   * have gone longer than the new value without refreshing.
   */
  refreshInactivityTimeoutSeconds?: number;
  /**
   * How long in seconds a session may last.
   *
   * Defaults to 30 days. Once it is reached, the user has to sign in again.
   *
   * A session expires at the sooner of this and its refresh inactivity timeout
   * (`refreshInactivityTimeoutSeconds`).
   *
   * Changes to this value apply to every session, including ones that already
   * exist: a session expires this long after it was created, under the value
   * configured when it is checked.
   */
  sessionMaxLifetimeSeconds?: number;
}): AuthCore<UsersTable> {
  const { component } = options;
  // Resolved once, when the app's modules load, so an invalid configuration
  // fails the deploy rather than the first sign-in.
  const ttl = resolveTtlConfig(options);
  // The default only matters to the type system (the core never touches the
  // table), but keep the value in sync with the `= "users"` default above.
  const usersTable = options.usersTable ?? ("users" as UsersTable);

  const refreshSession = mutationGeneric({
    args: { refreshToken: v.string() },
    returns: vRefreshResult,
    handler: async (ctx, args): Promise<RefreshResult> => {
      return await ctx.runMutation(component.public.refresh, {
        refreshToken: args.refreshToken,
        ...ttl,
      });
    },
  });

  const signOut = mutationGeneric({
    args: { refreshToken: v.string() },
    returns: v.null(),
    handler: async (ctx, args) => {
      await ctx.runMutation(component.public.signOut, {
        refreshToken: args.refreshToken,
      });
      return null;
    },
  });

  // Runs at the app deployment level (not inside the component) because only
  // there does `ctx.auth` reflect the caller's verified identity: Convex
  // checks the access token's signature against the deployment JWKS before
  // the handler runs, so a forged/unsigned token yields no identity here.
  const isAuthenticated = queryGeneric({
    args: {},
    returns: v.boolean(),
    handler: async (ctx): Promise<boolean> => {
      return (await getAuthUserId(ctx, component)) !== null;
    },
  });

  // Names of methods bound to this core, for duplicate detection. Scoped to
  // this `setupConvexAuth` call, since names only need to be unique within one
  // core.
  const boundMethodNames = new Set<string>();

  const bindMethod = <MethodName extends string, Profile>({
    name,
    createUser,
    onSignIn,
  }: {
    name: MethodName;
  } & UserCallbacks<
    MethodName,
    Profile,
    UsersTable
  >): MethodBuilders<Profile> => {
    if (boundMethodNames.has(name)) {
      throw new Error(
        `A sign-in method named "${name}" is already bound to this auth core. ` +
          `The app's callbacks get the name of the sign-in method as ` +
          `\`method.name\`, so each sign-in method must have a unique name.`,
      );
    }
    boundMethodNames.add(name);

    // Undefined when the app attached no `onSignIn`, which tells the core to
    // mint the session without notifying the app.
    const onSignInHandle = async (): Promise<string | undefined> =>
      onSignIn === undefined ? undefined : await createFunctionHandle(onSignIn);

    /**
     * Revoke the given sessions (as `listSessions` lists them) and count the
     * active ones revoked. Expired sessions are deleted too, but not counted. A
     * session expires one inactivity timeout after it last refreshed, or one
     * max lifetime after it was created, whichever comes first.
     */
    const revokeListedSessions = async (
      ctx: GenericMutationCtx<GenericDataModel>,
      sessions: {
        sessionId: string;
        creationTime: number;
        lastRefreshedAt: number;
      }[],
    ): Promise<number> => {
      if (sessions.length === 0) {
        return 0;
      }
      const revoked = new Set(
        await ctx.runMutation(component.public.revokeSessions, {
          sessionIds: sessions.map(({ sessionId }) => sessionId),
        }),
      );
      const maxLifetimeMs = ttl.sessionMaxLifetimeSeconds * 1000;
      const inactivityTimeoutMs = ttl.refreshInactivityTimeoutSeconds * 1000;
      const now = Date.now();
      return sessions.filter(
        ({ sessionId, creationTime, lastRefreshedAt }) =>
          revoked.has(sessionId) &&
          lastRefreshedAt + inactivityTimeoutMs > now &&
          creationTime + maxLifetimeMs > now,
      ).length;
    };

    // The helpers close over the live ctx.
    const makeHelpers = (ctx: GenericMutationCtx<GenericDataModel>) => ({
      completeSignUp: async (args: {
        profile: Profile;
        authenticatedBy: object;
      }): Promise<TokenBundle> => {
        return await ctx.runMutation(
          component.public._internal_dangerous_signUp,
          {
            claims: {
              method: name,
              profile: args.profile,
            },
            componentPath: componentPathOf(args.authenticatedBy),
            createUserHandle: await createFunctionHandle(createUser),
            onSignInHandle: await onSignInHandle(),
            ...ttl,
          },
        );
      },
      completeSignIn: async (args: {
        userId: string;
        profile: Profile;
        authenticatedBy: object;
      }): Promise<TokenBundle> => {
        return await ctx.runMutation(
          component.public._internal_dangerous_signIn,
          {
            claims: {
              method: name,
              profile: args.profile,
            },
            componentPath: componentPathOf(args.authenticatedBy),
            userId: args.userId,
            onSignInHandle: await onSignInHandle(),
            ...ttl,
          },
        );
      },
      signUpWithoutSession: async (args: {
        profile: Profile;
      }): Promise<{ userId: string }> => {
        return await ctx.runMutation(
          component.public._internal_dangerous_signUpWithoutSession,
          {
            claims: {
              method: name,
              profile: args.profile,
            },
            createUserHandle: await createFunctionHandle(createUser),
          },
        );
      },
      revokeOtherSessions: async (): Promise<number> => {
        const identity = await ctx.auth.getUserIdentity();
        if (identity === null) {
          return 0;
        }
        const currentSessionId = identity.subject;
        const session = await ctx.runQuery(component.public.getSession, {
          sessionId: currentSessionId,
        });
        // A revoked current session can't sign out other sessions.
        if (session === null) {
          return 0;
        }
        const sessions = await ctx.runQuery(component.public.listSessions, {
          userId: session.userId,
        });
        return await revokeListedSessions(
          ctx,
          sessions.filter(({ sessionId }) => sessionId !== currentSessionId),
        );
      },
      revokeAllSessions: async (userId: string): Promise<number> => {
        const sessions = await ctx.runQuery(component.public.listSessions, {
          userId,
        });
        return await revokeListedSessions(ctx, sessions);
      },
    });

    const authMutation: AuthMutationBuilder<Profile> = (fn) =>
      mutationGeneric({
        args: fn.args as PropertyValidators,
        returns: fn.returns,
        handler: (ctx, args) =>
          fn.handler(
            { ...ctx, convexAuth: makeHelpers(ctx) },
            args as Parameters<typeof fn.handler>[1],
          ),
      });

    return { authMutation };
  };

  return {
    usersTable,
    component,
    signOut,
    refreshSession,
    isAuthenticated,
    bindMethod,
  };
}
