import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import {
  accountFields,
  authorizationRequestsTable,
  ticketsTable,
} from "../../lib/oauth/schema.ts";

export default defineSchema({
  migrationLock: defineTable({ key: v.literal("auth-v2") }).index("by_key", [
    "key",
  ]),
  authorizationRequests: authorizationRequestsTable,
  tickets: ticketsTable,
  accounts: defineTable(accountFields)
    .index("providerAccountId", ["providerAccountId"])
    .index("by_userId", ["userId"]),
  erasedUsers: defineTable({
    userId: v.string(),
    requestedAt: v.number(),
  }).index("by_userId", ["userId"]),
  identityErasure: defineTable({
    digest: v.string(),
    cutoff: v.number(),
  }).index("by_digest", ["digest"]),
});
