import { v } from "convex/values";
import { mutation, type QueryCtx } from "./_generated/server.ts";
import { sha256Hex } from "../../lib/crypto.ts";

function erasedUser(ctx: QueryCtx, userId: string) {
  return ctx.db
    .query("erasedUsers")
    .withIndex("by_userId", (q) => q.eq("userId", userId))
    .unique();
}
function identityDigest(account: string) {
  // Same digest as the pre-stable core, so retained fences can be migrated.
  return sha256Hex(JSON.stringify(["google", account]));
}
export async function requireMigrationUnlocked(ctx: QueryCtx) {
  if (
    await ctx.db
      .query("migrationLock")
      .withIndex("by_key", (q) => q.eq("key", "auth-v2"))
      .unique()
  )
    throw new Error("Legacy auth migration is in progress.");
}
export async function assertIdentityActive(
  ctx: QueryCtx,
  account: string,
  userId: string | null,
) {
  await requireMigrationUnlocked(ctx);
  const digest = await identityDigest(account);
  const cutoff = await ctx.db
    .query("identityErasure")
    .withIndex("by_digest", (q) => q.eq("digest", digest))
    .unique();
  if (cutoff || (userId && (await erasedUser(ctx, userId))))
    throw new Error("Identity registration is unavailable.");
}

/** App-server only. Coordinate with the core/password/username/email fences atomically. */
export const beginUserErasure = mutation({
  args: { userId: v.string() },
  returns: v.null(),
  handler: async (ctx, { userId }) => {
    await requireMigrationUnlocked(ctx);
    if (!userId) throw new Error("Missing user ID.");
    if (!(await erasedUser(ctx, userId)))
      await ctx.db.insert("erasedUsers", { userId, requestedAt: Date.now() });
    return null;
  },
});

/** Bounded mapping removal with a permanent digest fence; re-registration is not supported. */
export const purgeUserLinkedAuth = mutation({
  args: { userId: v.string() },
  returns: v.object({ complete: v.boolean(), deletedAccounts: v.number() }),
  handler: async (ctx, { userId }) => {
    await requireMigrationUnlocked(ctx);
    const fence = await erasedUser(ctx, userId);
    if (!fence) throw new Error("Begin Google auth erasure first.");
    const rows = await ctx.db
      .query("accounts")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .take(101);
    for (const row of rows.slice(0, 100)) {
      const digest = await identityDigest(row.providerAccountId);
      const previous = await ctx.db
        .query("identityErasure")
        .withIndex("by_digest", (q) => q.eq("digest", digest))
        .unique();
      if (!previous)
        await ctx.db.insert("identityErasure", {
          digest,
          cutoff: fence.requestedAt,
        });
      else if (previous.cutoff < fence.requestedAt)
        await ctx.db.patch("identityErasure", previous._id, {
          cutoff: fence.requestedAt,
        });
      await ctx.db.delete("accounts", row._id);
    }
    return {
      complete: rows.length <= 100,
      deletedAccounts: Math.min(rows.length, 100),
    };
  },
});
