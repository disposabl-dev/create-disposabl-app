/** Component-only import primitives. They do not open auth or establish that a
 * source snapshot is complete; the app's atomic coordinator must do both. */
import { v } from "convex/values";
import { mutation } from "./_generated/server.ts";

const itemLimit = <T>(items: T[]) => {
  if (items.length > 100) throw new Error("Migration batch exceeds 100 rows");
};
export const importCutoffs = mutation({
  args: { rows: v.array(v.object({ digest: v.string(), cutoff: v.number() })) },
  returns: v.null(),
  handler: async (ctx, { rows }) => {
    itemLimit(rows);
    for (const row of rows) {
      if (!/^[a-f0-9]{64}$/.test(row.digest) || !Number.isFinite(row.cutoff))
        throw new Error("Invalid cutoff");
      const existing = await ctx.db
        .query("identityErasure")
        .withIndex("by_digest", (q) => q.eq("digest", row.digest))
        .unique();
      if (existing && existing.cutoff !== row.cutoff)
        throw new Error("Cutoff conflict");
      if (!existing) await ctx.db.insert("identityErasure", row);
    }
    return null;
  },
});
export const importErasedUsers = mutation({
  args: {
    rows: v.array(v.object({ userId: v.string(), requestedAt: v.number() })),
  },
  returns: v.null(),
  handler: async (ctx, { rows }) => {
    itemLimit(rows);
    for (const row of rows) {
      if (!row.userId || !Number.isFinite(row.requestedAt))
        throw new Error("Invalid user fence");
      const existing = await ctx.db
        .query("erasedUsers")
        .withIndex("by_userId", (q) => q.eq("userId", row.userId))
        .unique();
      if (existing && existing.requestedAt !== row.requestedAt)
        throw new Error("User fence conflict");
      if (!existing) await ctx.db.insert("erasedUsers", row);
    }
    return null;
  },
});
export const importAccounts = mutation({
  args: {
    rows: v.array(
      v.object({ providerAccountId: v.string(), userId: v.string() }),
    ),
  },
  returns: v.null(),
  handler: async (ctx, { rows }) => {
    itemLimit(rows);
    for (const row of rows) {
      if (!row.providerAccountId || !row.userId)
        throw new Error("Invalid mapping");
      const existing = await ctx.db
        .query("accounts")
        .withIndex("providerAccountId", (q) =>
          q.eq("providerAccountId", row.providerAccountId),
        )
        .unique();
      if (existing && existing.userId !== row.userId)
        throw new Error("Mapping conflict");
      if (!existing) await ctx.db.insert("accounts", row);
    }
    return null;
  },
});

/** Only the app's internal coordinator may hold or release this lock. */
export const _internal_dangerous_lock = mutation({
  args: {},
  returns: v.null(),
  handler: async (ctx) => {
    const row = await ctx.db
      .query("migrationLock")
      .withIndex("by_key", (q) => q.eq("key", "auth-v2"))
      .unique();
    if (!row) await ctx.db.insert("migrationLock", { key: "auth-v2" });
    return null;
  },
});
export const _internal_dangerous_unlock = mutation({
  args: {},
  returns: v.null(),
  handler: async (ctx) => {
    const row = await ctx.db
      .query("migrationLock")
      .withIndex("by_key", (q) => q.eq("key", "auth-v2"))
      .unique();
    if (row) await ctx.db.delete("migrationLock", row._id);
    return null;
  },
});
