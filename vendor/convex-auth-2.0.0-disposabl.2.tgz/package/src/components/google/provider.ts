import type { Doc } from "./_generated/dataModel.ts";
import { env, internalMutation, mutation, query } from "./_generated/server.ts";
import { buildProviderFunctions } from "../../lib/oauth/providerFunctions.ts";
import { v } from "convex/values";
import * as dbHelpers from "../../lib/oauth/dbHelpers.ts";
import { accountFields } from "../../lib/oauth/schema.ts";
import { assertIdentityActive } from "./erasure.ts";
export { beginUserErasure, purgeUserLinkedAuth } from "./erasure.ts";

export const {
  _internal_dangerous_createAuthorizationRequest,
  claimAuthorizationRequest,
  createTicket,
  claimTicket,
} = buildProviderFunctions<
  Doc<"authorizationRequests">,
  Doc<"tickets">,
  Doc<"accounts">
>({
  query,
  mutation,
  internalMutation,
  clientId: () => {
    if (!env.CLIENT_ID) throw new Error("Google CLIENT_ID is not configured.");
    return env.CLIENT_ID;
  },
});

export const getUserIdByAccount = query({
  args: { providerAccountId: v.string() },
  returns: v.union(v.string(), v.null()),
  handler: async (ctx, args) => {
    const userId = await dbHelpers.findAccountUserId<Doc<"accounts">>(
      ctx,
      args,
    );
    await assertIdentityActive(ctx, args.providerAccountId, userId);
    return userId;
  },
});
export const _internal_dangerous_createAccount = mutation({
  args: accountFields,
  returns: v.null(),
  handler: async (ctx, args) => {
    await assertIdentityActive(ctx, args.providerAccountId, args.userId);
    return dbHelpers.insertAccount<Doc<"accounts">>(ctx, args);
  },
});
