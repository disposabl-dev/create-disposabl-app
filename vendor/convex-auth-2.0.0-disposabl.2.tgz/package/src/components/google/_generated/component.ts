/* eslint-disable */
/**
 * Generated `ComponentApi` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type { FunctionReference } from "convex/server";

/**
 * A utility for referencing a Convex component's exposed API.
 *
 * Useful when expecting a parameter like `components.myComponent`.
 * Usage:
 * ```ts
 * async function myFunction(ctx: QueryCtx, component: ComponentApi) {
 *   return ctx.runQuery(component.someFile.someQuery, { ...args });
 * }
 * ```
 */
export type ComponentApi<Name extends string | undefined = string | undefined> =
  {
    erasure: {
      beginUserErasure: FunctionReference<
        "mutation",
        "internal",
        { userId: string },
        null,
        Name
      >;
      purgeUserLinkedAuth: FunctionReference<
        "mutation",
        "internal",
        { userId: string },
        { complete: boolean; deletedAccounts: number },
        Name
      >;
    };
    migration: {
      _internal_dangerous_lock: FunctionReference<
        "mutation",
        "internal",
        {},
        null,
        Name
      >;
      _internal_dangerous_unlock: FunctionReference<
        "mutation",
        "internal",
        {},
        null,
        Name
      >;
      importAccounts: FunctionReference<
        "mutation",
        "internal",
        { rows: Array<{ providerAccountId: string; userId: string }> },
        null,
        Name
      >;
      importCutoffs: FunctionReference<
        "mutation",
        "internal",
        { rows: Array<{ cutoff: number; digest: string }> },
        null,
        Name
      >;
      importErasedUsers: FunctionReference<
        "mutation",
        "internal",
        { rows: Array<{ requestedAt: number; userId: string }> },
        null,
        Name
      >;
    };
    provider: {
      _internal_dangerous_createAccount: FunctionReference<
        "mutation",
        "internal",
        { providerAccountId: string; userId: string },
        null,
        Name
      >;
      _internal_dangerous_createAuthorizationRequest: FunctionReference<
        "mutation",
        "internal",
        { codeVerifier: string; redirectTo: string; stateHash: string },
        { callbackUrl: string; clientId: string },
        Name
      >;
      beginUserErasure: FunctionReference<
        "mutation",
        "internal",
        { userId: string },
        null,
        Name
      >;
      claimTicket: FunctionReference<
        "mutation",
        "internal",
        { stateHash: string; ticketCodeHash: string },
        null | { encryptedPayload: string },
        Name
      >;
      getUserIdByAccount: FunctionReference<
        "query",
        "internal",
        { providerAccountId: string },
        string | null,
        Name
      >;
      purgeUserLinkedAuth: FunctionReference<
        "mutation",
        "internal",
        { userId: string },
        { complete: boolean; deletedAccounts: number },
        Name
      >;
    };
  };
