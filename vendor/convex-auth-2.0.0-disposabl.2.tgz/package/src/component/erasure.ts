import { v } from "convex/values";
import { mutation, type QueryCtx } from "./_generated/server.ts";

export function erasedUser(ctx: QueryCtx, userId: string) {
  return ctx.db
    .query("erasedUsers")
    .withIndex("by_userId", (q) => q.eq("userId", userId))
    .unique();
}
export async function requireMigrationComplete(ctx: QueryCtx) {
  const control = await ctx.db
    .query("migrationControl")
    .withIndex("by_key", (q) => q.eq("key", "auth-v2"))
    .unique();
  if (control?.complete) return;
  if (control) throw new Error("Legacy auth migration is not complete.");
  if (
    (await ctx.db.query("accounts").first()) ||
    (await ctx.db.query("identityErasure").first()) ||
    (await ctx.db
      .query("sessions")
      .withIndex("by_component", (q) => q.eq("component", undefined))
      .first())
  )
    throw new Error("Legacy auth migration is not complete.");
}
export async function requireActiveUser(ctx: QueryCtx, userId: string) {
  await requireMigrationComplete(ctx);
  if (await erasedUser(ctx, userId))
    throw new Error("Auth account is unavailable.");
}

/** App-server-only fence; establish provider fences in the same app mutation. */
export const beginUserErasure = mutation({
  args: { userId: v.string() },
  returns: v.null(),
  handler: async (ctx, { userId }) => {
    await requireMigrationComplete(ctx);
    if (!userId) throw new Error("Missing user ID.");
    if (!(await erasedUser(ctx, userId)))
      await ctx.db.insert("erasedUsers", { userId, requestedAt: Date.now() });
    return null;
  },
});

/** Only core-owned sessions and tokens. Stable v2 provider accounts are separate. */
export const purgeUserLinkedAuth = mutation({
  args: { userId: v.string() },
  returns: v.object({
    linkedRowsCleared: v.boolean(),
    deletedAccounts: v.number(),
    deletedSessions: v.number(),
    deletedRefreshTokens: v.number(),
    legacyOrphansUnverified: v.literal(true),
  }),
  handler: async (ctx, { userId }) => {
    if (!(await erasedUser(ctx, userId)))
      throw new Error("Begin auth erasure first.");
    const result = {
      linkedRowsCleared: false,
      deletedAccounts: 0,
      deletedSessions: 0,
      deletedRefreshTokens: 0,
      legacyOrphansUnverified: true as const,
    };
    const receipt = await ctx.db
      .query("sessionCleanupReceipts")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();
    const session = receipt
      ? null
      : await ctx.db
          .query("sessions")
          .withIndex("by_user", (q) => q.eq("userId", userId))
          .first();
    const sessionId = receipt?.sessionId ?? session?._id;
    if (sessionId) {
      const tokens = await ctx.db
        .query("refreshTokens")
        .withIndex("by_session_state", (q) => q.eq("sessionId", sessionId))
        .take(101);
      for (const token of tokens.slice(0, 100))
        await ctx.db.delete("refreshTokens", token._id);
      result.deletedRefreshTokens = Math.min(tokens.length, 100);
      if (tokens.length <= 100) {
        if (receipt) await ctx.db.delete("sessionCleanupReceipts", receipt._id);
        else if (session) {
          await ctx.db.delete("sessions", session._id);
          result.deletedSessions = 1;
        }
      }
      return result;
    }
    const created = await ctx.db
      .query("createdUserIds")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .take(101);
    for (const row of created.slice(0, 100))
      await ctx.db.delete("createdUserIds", row._id);
    return { ...result, linkedRowsCleared: created.length <= 100 };
  },
});
