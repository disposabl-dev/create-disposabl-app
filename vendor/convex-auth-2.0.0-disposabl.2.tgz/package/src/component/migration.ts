/** Read-only legacy component exports. App-internal orchestration must copy each
 * page atomically with progress and keep auth gated until verification. */
import { paginationOptsValidator } from "convex/server";
import { query, mutation } from "./_generated/server.ts";
import { v } from "convex/values";

export const googleAccounts = query({
  args: { paginationOpts: paginationOptsValidator },
  handler: async (ctx, { paginationOpts }) => {
    if (paginationOpts.numItems < 1 || paginationOpts.numItems > 100)
      throw new Error("Invalid batch size");
    return await ctx.db
      .query("accounts")
      .withIndex("by_provider_account", (q) => q.eq("provider", "google"))
      .paginate(paginationOpts);
  },
});
export const identityCutoffs = query({
  args: { paginationOpts: paginationOptsValidator },
  handler: async (ctx, { paginationOpts }) => {
    if (paginationOpts.numItems < 1 || paginationOpts.numItems > 100)
      throw new Error("Invalid batch size");
    return await ctx.db.query("identityErasure").paginate(paginationOpts);
  },
});
export const erasedUsers = query({
  args: { paginationOpts: paginationOptsValidator },
  handler: async (ctx, { paginationOpts }) => {
    if (paginationOpts.numItems < 1 || paginationOpts.numItems > 100)
      throw new Error("Invalid batch size");
    return await ctx.db.query("erasedUsers").paginate(paginationOpts);
  },
});
/** Delete one old session's tokens in bounded batches, then the session.
 * Stable sessions remain untouched; historical unattributed orphan tokens remain. */
export const retireLegacySession = mutation({
  args: {},
  returns: v.object({
    done: v.boolean(),
    deletedTokens: v.number(),
    deletedSession: v.boolean(),
  }),
  handler: async (ctx) => {
    const session = await ctx.db
      .query("sessions")
      .withIndex("by_component", (q) => q.eq("component", undefined))
      .first();
    if (!session)
      return { done: true, deletedTokens: 0, deletedSession: false };
    const tokens = await ctx.db
      .query("refreshTokens")
      .withIndex("by_session_state", (q) => q.eq("sessionId", session._id))
      .take(101);
    for (const token of tokens.slice(0, 100))
      await ctx.db.delete("refreshTokens", token._id);
    if (tokens.length <= 100) await ctx.db.delete("sessions", session._id);
    return {
      done: false,
      deletedTokens: Math.min(tokens.length, 100),
      deletedSession: tokens.length <= 100,
    };
  },
});

/**
 * DANGER: only invoke from an app-internal transaction which imports the
 * returned rows into the Google component before returning. A failed import
 * must roll back this progress. Never expose this component function publicly.
 */
export const _internal_dangerous_advance = mutation({
  args: {},
  returns: v.object({
    phase: v.union(
      v.literal("cutoffs"),
      v.literal("users"),
      v.literal("accounts"),
      v.literal("sessions"),
      v.literal("complete"),
    ),
    rows: v.array(
      v.union(
        v.object({ digest: v.string(), cutoff: v.number() }),
        v.object({ userId: v.string(), requestedAt: v.number() }),
        v.object({
          provider: v.string(),
          providerAccountId: v.string(),
          userId: v.string(),
        }),
      ),
    ),
  }),
  handler: async (ctx) => {
    let state = await ctx.db
      .query("migrationControl")
      .withIndex("by_key", (q) => q.eq("key", "auth-v2"))
      .unique();
    if (!state) {
      const id = await ctx.db.insert("migrationControl", {
        key: "auth-v2",
        complete: false,
        phase: "cutoffs",
      });
      state = await ctx.db.get("migrationControl", id);
    }
    if (!state) throw new Error("Migration state missing");
    if (state.complete) return { phase: "complete" as const, rows: [] };
    const phase = state.phase;
    if (!phase) throw new Error("Invalid migration phase");
    const paginationOpts = { cursor: state.cursor ?? null, numItems: 100 };
    if (phase === "sessions") {
      const session = await ctx.db
        .query("sessions")
        .withIndex("by_component", (q) => q.eq("component", undefined))
        .first();
      if (session) {
        const tokens = await ctx.db
          .query("refreshTokens")
          .withIndex("by_session_state", (q) => q.eq("sessionId", session._id))
          .take(101);
        for (const token of tokens.slice(0, 100))
          await ctx.db.delete("refreshTokens", token._id);
        if (tokens.length <= 100) await ctx.db.delete("sessions", session._id);
        return { phase, rows: [] };
      }
      await ctx.db.patch("migrationControl", state._id, {
        complete: true,
        phase: undefined,
        cursor: undefined,
      });
      return { phase: "complete" as const, rows: [] };
    }
    const result =
      phase === "cutoffs"
        ? await ctx.db.query("identityErasure").paginate(paginationOpts)
        : phase === "users"
          ? await ctx.db.query("erasedUsers").paginate(paginationOpts)
          : phase === "accounts"
            ? await ctx.db
                .query("accounts")
                .withIndex("by_provider_account", (q) =>
                  q.eq("provider", "google"),
                )
                .paginate(paginationOpts)
            : null;
    if (!result) throw new Error("Invalid migration phase");
    const next =
      phase === "cutoffs"
        ? "users"
        : phase === "users"
          ? "accounts"
          : "sessions";
    await ctx.db.patch(
      "migrationControl",
      state._id,
      result.isDone
        ? { phase: next, cursor: undefined }
        : { cursor: result.continueCursor },
    );
    return {
      phase,
      rows: result.page.map(({ _id, _creationTime, ...row }) => row),
    };
  },
});
