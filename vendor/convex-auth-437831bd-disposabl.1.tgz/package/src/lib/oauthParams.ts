/**
 * URL query param names used by the OAuth component, appended to callback
 * redirects back to the browser.
 *
 * They are deliberately prefixed with `convexAuth` rather than the bare
 * `code`/`error` an OAuth callback would normally use, so they can't collide
 * with URL params that an app may use for other reasons. The client's callback
 * handler is registered unconditionally (every app that uses Convex Auth runs
 * it on every page load), so bare names would let it consume
 * `?code=`/`?error=` params from an unrelated flow the app runs. A
 * `convexAuth`-prefixed param signals the redirect came from this component,
 * which is also what keeps the client's `INVALID_FLOW` detection meaningful.
 *
 * Shared by the component (which writes them) and the browser client (which
 * reads them) so the two ends can never drift.
 *
 * @module
 */

/** Carries the one-time code the client redeems for a session. */
export const OAUTH_CODE_PARAM = "convexAuthCode";

/**
 * Carries why the flow failed: `access_denied`, `expired`, or `oauth_error`.
 */
export const OAUTH_ERROR_PARAM = "convexAuthError";
